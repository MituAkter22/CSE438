package com.example.mealmatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
